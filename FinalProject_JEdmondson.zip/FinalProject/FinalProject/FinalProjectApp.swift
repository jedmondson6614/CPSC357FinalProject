//
//  FinalProjectApp.swift
//  FinalProject
//
//  Created by Josh Edmondson on 12/9/23.
//

import SwiftUI

@main
struct FinalProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
