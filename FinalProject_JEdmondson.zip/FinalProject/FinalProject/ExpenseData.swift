//
//  ExpenseData.swift
//  FinalProject
//
//  Created by Josh Edmondson on 12/10/23.
//

import Foundation

struct ExpenseDataPoint: Identifiable{
    var id = UUID().uuidString
    var name: String
    var amount: Int
}
