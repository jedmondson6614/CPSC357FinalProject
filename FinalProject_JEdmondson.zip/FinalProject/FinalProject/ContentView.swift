//
//  ContentView.swift
//  FinalProject
//
//  Created by Josh Edmondson on 12/9/23.
//

import SwiftUI
import Charts

struct ContentView: View {
    @State var mainIncome = ""
    @State var otherIncome = ""
    @State var rent = ""
    @State var mortgage = ""
    @State var water = ""
    @State var gas = ""
    @State var electricity = ""
    @State var otherExpenses = ""
    @State private var selection = 1
    var body: some View {
        let mainIncomeInt = Int(mainIncome) ?? 0
        let otherIncomeInt = Int(otherIncome) ?? 0
        let rentInt = Int(rent) ?? 0
        let mortgageInt = Int(mortgage) ?? 0
        let waterInt = Int(water) ?? 0
        let gasInt = Int(gas) ?? 0
        let electricityInt = Int(electricity) ?? 0
        let otherExpensesInt = Int(otherExpenses) ?? 0
        
        let totalExpenses = rentInt + mortgageInt + waterInt + gasInt + electricityInt + otherExpensesInt
        let utilitiesExpenses = waterInt + gasInt + electricityInt
        let propertyExpenses = rentInt + mortgageInt
        let budget = (mainIncomeInt + otherIncomeInt) - (rentInt + mortgageInt + waterInt + gasInt + electricityInt + otherExpensesInt)
        var data = [
            ExpenseDataPoint(name: "Rent", amount: rentInt),
            ExpenseDataPoint(name: "Mortgage", amount: mortgageInt),
            ExpenseDataPoint(name: "Water", amount: waterInt),
            ExpenseDataPoint(name: "Gas", amount: gasInt),
            ExpenseDataPoint(name: "Electricity", amount: electricityInt),
            ExpenseDataPoint(name: "Other", amount: otherExpensesInt)
        ]
        TabView(selection: $selection){
            VStack{
                Text("Budget Calculator")
                    .bold()
                    .padding()
                Text("This application allows you to input your income with your expenses and shows you the deductions and a chart of your expenses.")
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                Text("Instructions:")
                Text("Use the tabs to move between the sections of the app.")
                    .font(.title)
                Text("Type your answers to the nearest integer, otherwise the answer will be interpreted as 0.")
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .padding()
            }
                .tabItem {
                    Image(systemName: "1.circle")
                    Text("Information")
                }.tag(1)
            VStack{
                Text("Main Income:")
                TextField("Enter Value", text: $mainIncome)
                    .frame(width: 200)
                    .border(.black)
                Text("Other Income:")
                TextField("Enter Value", text: $otherIncome)
                    .frame(width: 200)
                    .border(.black)
                
            }
                .tabItem {
                    Image(systemName: "2.circle")
                    Text("Income")
                }.tag(2)
            VStack{
                Text("Rent:")
                TextField("Enter Value", text: $rent)
                    .frame(width: 200)
                    .border(.black)
                Text("Mortgage:")
                TextField("Enter Value", text: $mortgage)
                    .frame(width: 200)
                    .border(.black)
                Text("Water:")
                TextField("Enter Value", text: $water)
                    .frame(width: 200)
                    .border(.black)
                Text("Gas:")
                TextField("Enter Value", text: $gas)
                    .frame(width: 200)
                    .border(.black)
                Text("Electricity:")
                TextField("Enter Value", text: $electricity)
                    .frame(width: 200)
                    .border(.black)
                Text("Other Expenses:")
                TextField("Enter Value", text: $otherExpenses)
                    .frame(width: 200)
                    .border(.black)
            }
                .tabItem {
                    Image(systemName: "3.circle")
                    Text("Expenses")
                }.tag(3)
            VStack{
                Text("Total Budget: " + String(budget))
                Text("Total Expenses: " + String(totalExpenses))
                Text("Utilities Expenses: " + String(utilitiesExpenses))
                
            }
                .tabItem {
                    Image(systemName: "4.circle")
                    Text("Deductions")
                }.tag(4)
            VStack{
                Chart {
                    ForEach (data) { d in
                        SectorMark(angle: .value("Expense", d.amount))
                            .foregroundStyle(by: .value("Name", d.name))
                    }
                }
            }
            .tabItem {
                Image(systemName: "5.circle")
                Text("Chart")
            }.tag(5)
        }
        .font(.largeTitle)
    }
    
    
}

#Preview {
    ContentView()
}
